# Both the folder and the file are added to the same level of the package.json


# install the following packages
    # "devDependencies": {
    "@eslint/js": "^9.13.0",
    "eslint": "^9.13.0",
    "eslint-plugin-jest": "^28.8.3",
    "eslint-plugin-node": "^11.1.0",
  }


# Add this to package.json in the scripts: “lint”: “npx eslint”


# Run: npm run lint.
